package com.oms.orderservice.order.Exception;

public class OrderDateMissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public OrderDateMissingException(String message){
		super(message);
	}
}
