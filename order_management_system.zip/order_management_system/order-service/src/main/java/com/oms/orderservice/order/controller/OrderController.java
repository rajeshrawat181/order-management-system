package com.oms.orderservice.order.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.oms.orderservice.order.common.ErrorCodes;
import com.oms.orderservice.order.model.Order;
import com.oms.orderservice.order.service.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;

	@PostMapping("/create-order")
	public ResponseEntity<?> createOrder(@RequestBody Order order) {   
		orderService.createOrder(order);
		return ResponseEntity.status(HttpStatus.OK).body(ErrorCodes.ORDER_CREATED.getDescription());
	}
	@GetMapping("/retrieve-orders")
	public ResponseEntity<?> retrieveOrders() {
		return ResponseEntity.status(HttpStatus.OK).body( orderService.retrieveOrder());
	}
	
	// next there may be multiple endpoints for criteria based operation
}
