package com.oms.orderservice.order.validation;

import org.springframework.util.StringUtils;

import com.oms.orderservice.order.Exception.AddressMissingException;
import com.oms.orderservice.order.Exception.AmountMissingException;
import com.oms.orderservice.order.Exception.CustomerIdMissingException;
import com.oms.orderservice.order.Exception.CustomerNameMissingException;
import com.oms.orderservice.order.Exception.OrderDateMissingException;
import com.oms.orderservice.order.Exception.OrderItemMissingException;
import com.oms.orderservice.order.Exception.orderItem.ProductCodeMissingException;
import com.oms.orderservice.order.Exception.orderItem.ProductNameMissingException;
import com.oms.orderservice.order.Exception.orderItem.QuantityMissingException;
import com.oms.orderservice.order.common.ErrorCodes;
import com.oms.orderservice.order.model.Order;
import com.oms.orderservice.order.model.OrderItem;

public class OrderValidation {

	public static void isValidOrder(Order order) {

		if (StringUtils.isEmpty(order.getCustomerId()))
			 throw new CustomerIdMissingException(ErrorCodes.CUSTOMER_ID_MISSING.getDescription());
		if (StringUtils.isEmpty(order.getCustomerName()))
			throw new CustomerNameMissingException(ErrorCodes.CUSTOMER_NAME_MISSING.getDescription());
		
		if (StringUtils.isEmpty(order.getCustomerName()))
			throw new OrderDateMissingException(ErrorCodes.ORDER_DATE_MISSING.getDescription());
		
		if (StringUtils.isEmpty(order.getCustomerName()))
			throw new AddressMissingException(ErrorCodes.ADDRESS_MISSING.getDescription());
		
		if (StringUtils.isEmpty(order.getCustomerName()))
			throw new AmountMissingException(ErrorCodes.ORDER_AMOUNT_MISSING.getDescription());
		
		if (StringUtils.isEmpty(order.getCustomerName()))
			throw new OrderItemMissingException(ErrorCodes.ORDER_ITEM_MISSING.getDescription());

	}

	public static void isValidOrderItem(OrderItem orderItem) {
		
		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new ProductCodeMissingException(ErrorCodes.PRODUCT_CODE_MISSING.getDescription());

		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new ProductCodeMissingException(ErrorCodes.PRODUCT_CODE_MISSING.getDescription());

		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new ProductNameMissingException(ErrorCodes.PRODUCT_NAME_MISSING.getDescription());
		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new QuantityMissingException(ErrorCodes.QUANTITY_MISSING.getDescription());

	}

}
