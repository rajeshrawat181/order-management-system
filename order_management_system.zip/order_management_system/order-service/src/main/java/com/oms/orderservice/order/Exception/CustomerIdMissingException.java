package com.oms.orderservice.order.Exception;

public class CustomerIdMissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public CustomerIdMissingException(String message){
		super(message);
	}
}
