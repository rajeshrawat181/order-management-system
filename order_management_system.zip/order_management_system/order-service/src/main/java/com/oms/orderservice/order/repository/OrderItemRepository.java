package com.oms.orderservice.order.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.oms.orderservice.order.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long>{

}
