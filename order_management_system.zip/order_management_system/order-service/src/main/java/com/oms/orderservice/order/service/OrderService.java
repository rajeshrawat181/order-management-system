package com.oms.orderservice.order.service;

import java.util.List;
import com.oms.orderservice.order.model.Order;

public interface OrderService {

	void createOrder(Order order);
	List<Order> retrieveOrder();

}
