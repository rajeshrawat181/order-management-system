package com.oms.orderservice.order.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.oms.orderservice.order.Exception.AddressMissingException;
import com.oms.orderservice.order.Exception.AmountMissingException;
import com.oms.orderservice.order.Exception.CustomerIdMissingException;
import com.oms.orderservice.order.Exception.CustomerNameMissingException;
import com.oms.orderservice.order.Exception.OrderDateMissingException;
import com.oms.orderservice.order.Exception.OrderItemMissingException;
import com.oms.orderservice.order.Exception.OrderNotFoundException;
import com.oms.orderservice.order.Exception.orderItem.ProductCodeMissingException;
import com.oms.orderservice.order.Exception.orderItem.ProductNameMissingException;
import com.oms.orderservice.order.Exception.orderItem.QuantityMissingException;
import com.oms.orderservice.order.common.ErrorCodes;
import com.oms.orderservice.order.common.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class ExceptionAdvice {

	@ExceptionHandler(value = OrderNotFoundException.class)
	public ResponseEntity<?> exception(OrderNotFoundException e) {

		log.error("Order note found :", e);
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.ORDER_NOT_FOUND.getCode())
						.errorMessage(ErrorCodes.ORDER_NOT_FOUND.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = AddressMissingException.class)
	public ResponseEntity<?> exception(AddressMissingException e) {

		log.error("Address missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.ADDRESS_MISSING.getCode())
						.errorMessage(ErrorCodes.ADDRESS_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = AmountMissingException.class)
	public ResponseEntity<?> exception(AmountMissingException e) {

		log.error("Amount missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.ORDER_AMOUNT_MISSING.getCode())
						.errorMessage(ErrorCodes.ORDER_AMOUNT_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = CustomerIdMissingException.class)
	public ResponseEntity<?> exception(CustomerIdMissingException e) {

		log.error("Customer id missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.CUSTOMER_ID_MISSING.getCode())
						.errorMessage(ErrorCodes.CUSTOMER_ID_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = CustomerNameMissingException.class)
	public ResponseEntity<?> exception(CustomerNameMissingException e) {

		log.error("ECustomer name missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.CUSTOMER_NAME_MISSING.getCode())
						.errorMessage(ErrorCodes.CUSTOMER_NAME_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = OrderDateMissingException.class)
	public ResponseEntity<?> exception(OrderDateMissingException e) {

		log.error("Order date missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.ORDER_DATE_MISSING.getCode())
						.errorMessage(ErrorCodes.ORDER_DATE_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = OrderItemMissingException.class)
	public ResponseEntity<?> exception(OrderItemMissingException e) {

		log.error("Order items missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.ORDER_ITEM_MISSING.getCode())
						.errorMessage(ErrorCodes.ORDER_ITEM_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = ProductCodeMissingException.class)
	public ResponseEntity<?> exception(ProductCodeMissingException e) {

		log.error("Product code missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.PRODUCT_CODE_MISSING.getCode())
						.errorMessage(ErrorCodes.PRODUCT_CODE_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = ProductNameMissingException.class)
	public ResponseEntity<?> exception(ProductNameMissingException e) {

		log.error("Product name missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.PRODUCT_NAME_MISSING.getCode())
						.errorMessage(ErrorCodes.PRODUCT_NAME_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = QuantityMissingException.class)
	public ResponseEntity<?> exception(QuantityMissingException e) {

		log.error("Quantity missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.QUANTITY_MISSING.getCode())
						.errorMessage(ErrorCodes.QUANTITY_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<?> handleGenericNotFoundException(Exception e) {
		log.error("Error while processing order :", e);
		return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);

	}

}
