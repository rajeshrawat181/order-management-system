package com.oms.orderservice.order.service.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oms.orderservice.order.Exception.OrderNotFoundException;
import com.oms.orderservice.order.model.Order;
import com.oms.orderservice.order.model.OrderItem;
import com.oms.orderservice.order.repository.OrderRepository;
import com.oms.orderservice.order.service.OrderService;
import com.oms.orderservice.order.validation.OrderValidation;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	OrderRepository orderRepository;

	@Override
	public void createOrder(Order order) {
		OrderValidation.isValidOrder(order);
		Set<OrderItem> orserItems = order.getOrderItems();
		for (OrderItem orderItem : orserItems) {
			OrderValidation.isValidOrderItem(orderItem);
		}
		orderRepository.save(order);
	}

	@Override
	public List<Order> retrieveOrder() {
		List<Order> orders = orderRepository.findAll();
		if (orders == null || orders.isEmpty())
			throw new OrderNotFoundException("Order not found");
		return orders;
	}

}
