package com.oms.orderservice.order.Exception.orderItem;

public class QuantityMissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public QuantityMissingException(String message){
		super(message);
	}
}
