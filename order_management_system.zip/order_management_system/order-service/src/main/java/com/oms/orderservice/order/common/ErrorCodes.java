package com.oms.orderservice.order.common;

public enum ErrorCodes {

	  ORDER_CREATED("1", "Order created successfully."),
	  CUSTOMER_ID_MISSING("ERR_001", "Customer id not found."),
	  CUSTOMER_NAME_MISSING("ERR_002", "Customer name not found."),
	  ORDER_DATE_MISSING("ERR_003", "Order date not found."),
	  ADDRESS_MISSING("ERR_004", "Address not found."),
	  ORDER_ITEM_MISSING("ERR_005", "Order items not found."), 
	  ORDER_AMOUNT_MISSING("ERR_006", "Order amount not found."),
	  PRODUCT_CODE_MISSING("ERR_007", "Product code not found."),
	  PRODUCT_NAME_MISSING("ERR_008", "Product name not found."),
	  QUANTITY_MISSING("ERR_008", "Quantity not found."),
	  ORDER_NOT_FOUND("ERR_009", "Order not found.");
	 
	  

	  private final String code;
	  private final String description;

	  private ErrorCodes(String code, String description) {
	    this.code = code;
	    this.description = description;
	  }

	  public String getDescription() {
	     return description;
	  }

	  public String getCode() {
	     return code;
	  }

	  @Override
	  public String toString() {
	    return code + ": " + description;
	  }
}
