package com.oms.orderitemservice.item.validation;

import org.springframework.util.StringUtils;

import com.oms.orderitemservice.item.Exception.orderItem.ProductCodeMissingException;
import com.oms.orderitemservice.item.Exception.orderItem.ProductNameMissingException;
import com.oms.orderitemservice.item.Exception.orderItem.QuantityMissingException;
import com.oms.orderitemservice.item.common.ErrorCodes;
import com.oms.orderitemservice.item.model.OrderItem;

public class OrderItemValidation {

	public static void isValidOrderItem(OrderItem orderItem) {
		
		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new ProductCodeMissingException(ErrorCodes.PRODUCT_CODE_MISSING.getDescription());

		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new ProductCodeMissingException(ErrorCodes.PRODUCT_CODE_MISSING.getDescription());

		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new ProductNameMissingException(ErrorCodes.PRODUCT_NAME_MISSING.getDescription());
		if (StringUtils.isEmpty(orderItem.getProductCode()))
			throw new QuantityMissingException(ErrorCodes.QUANTITY_MISSING.getDescription());

	}

}
