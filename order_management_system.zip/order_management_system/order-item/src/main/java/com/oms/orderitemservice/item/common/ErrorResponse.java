package com.oms.orderitemservice.item.common;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
@Builder
public class ErrorResponse implements Serializable{
	private static final long serialVersionUID = 652866090849945103L;
	
	private String errorCode;
	private String errorMessage;
	private LocalDateTime timeStamp;

}
