package com.oms.orderitemservice.item.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.oms.orderitemservice.item.common.ErrorCodes;
import com.oms.orderitemservice.item.model.OrderItem;
import com.oms.orderitemservice.item.service.OrderItemService;

@RestController
public class OrderItemController {

	@Autowired
	OrderItemService orderItemService;

	@PostMapping("/create-order-item")
	public ResponseEntity<?> createOrderItem(@RequestBody OrderItem orderItem) {

		orderItemService.createOrderItem(orderItem);
		return ResponseEntity.status(HttpStatus.OK).body(ErrorCodes.ITEM_CREATED.getDescription());	
	}
	@GetMapping("/retrieve-order-item")
	public ResponseEntity<?> retrieveOrderItem() {
		return ResponseEntity.status(HttpStatus.OK).body( orderItemService.retrieveOrderItem());
	}
	// next there may be multiple endpoints for criteria based operation
}
