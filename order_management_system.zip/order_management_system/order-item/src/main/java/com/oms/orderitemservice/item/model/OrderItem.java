package com.oms.orderitemservice.item.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.joda.time.DateTime;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "order-items")
@Setter
@Getter
@ToString
public class OrderItem implements Serializable{
	private static final long serialVersionUID = -3615309994976346065L;
	
	 
    @Id
    @GeneratedValue
    @Column(name = "order-item-id", nullable = false)
    private Long orderItemId;
    private String productCode;
    private String ProductName;
    private int quantity;
    @ManyToOne
    @JoinColumn(name = "order_id")
    private Order order;
    private boolean status;
    private DateTime createdOn;
    private String createdBy;
    private DateTime updatedOn;
    private String updatedBy;

}
