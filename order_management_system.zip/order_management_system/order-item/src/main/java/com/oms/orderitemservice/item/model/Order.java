package com.oms.orderitemservice.item.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.joda.time.DateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "orders")
@Setter
@Getter
@ToString
public class Order implements Serializable {

	private static final long serialVersionUID = 7043960332411764518L;

	@Id
	@GeneratedValue
	@Column(name = "order_id", nullable = false)
	private Long orderId;
	private String customerId;
	private String customerName;
	private DateTime orderDate;
	private String shippingAddress;
	@OneToMany(fetch = FetchType.LAZY,mappedBy = "order", cascade = CascadeType.ALL)
	private Set<OrderItem> orderItems;
	private double total;
	private boolean status;
	private DateTime createdOn;
	private String createdBy;
	private DateTime updatedOn;
	private String updatedBy;

}
