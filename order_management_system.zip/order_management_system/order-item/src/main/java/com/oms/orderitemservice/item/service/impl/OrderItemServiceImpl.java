package com.oms.orderitemservice.item.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oms.orderitemservice.item.Exception.OrderItemNotFoundException;
import com.oms.orderitemservice.item.model.OrderItem;
import com.oms.orderitemservice.item.repository.OrderItemRepository;
import com.oms.orderitemservice.item.service.OrderItemService;
import com.oms.orderitemservice.item.validation.OrderItemValidation;

@Service
public class OrderItemServiceImpl implements OrderItemService{

	@Autowired
	OrderItemRepository orderItemRepository;

	@Override
	public void createOrderItem(OrderItem orderItem) {
		OrderItemValidation.isValidOrderItem(orderItem);
		orderItemRepository.save(orderItem);
		
	}

	@Override
	public List<OrderItem> retrieveOrderItem() {
		List<OrderItem> ordersItem = orderItemRepository.findAll();
		if (ordersItem == null || ordersItem.isEmpty())
			throw new OrderItemNotFoundException("Order item not found");
		return ordersItem;
	}

}
