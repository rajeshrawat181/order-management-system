package com.oms.orderitemservice.item.Exception.orderItem;

public class ProductCodeMissingException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public ProductCodeMissingException(String message){
		super(message);
	}
}
