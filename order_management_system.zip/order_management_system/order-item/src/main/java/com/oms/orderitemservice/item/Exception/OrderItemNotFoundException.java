package com.oms.orderitemservice.item.Exception;

public class OrderItemNotFoundException extends RuntimeException{

	private static final long serialVersionUID = -7171193668383158161L;

	public OrderItemNotFoundException(String message){
		super(message);
	}
}
