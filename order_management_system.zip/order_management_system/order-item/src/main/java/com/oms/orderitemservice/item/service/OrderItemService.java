package com.oms.orderitemservice.item.service;

import java.util.List;

import com.oms.orderitemservice.item.model.OrderItem;

public interface OrderItemService {

	void createOrderItem(OrderItem orderItem);

	List<OrderItem> retrieveOrderItem();

}
