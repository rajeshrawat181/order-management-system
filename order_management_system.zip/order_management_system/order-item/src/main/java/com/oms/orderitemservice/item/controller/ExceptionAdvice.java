package com.oms.orderitemservice.item.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.oms.orderitemservice.item.Exception.OrderItemNotFoundException;
import com.oms.orderitemservice.item.Exception.orderItem.ProductCodeMissingException;
import com.oms.orderitemservice.item.Exception.orderItem.ProductNameMissingException;
import com.oms.orderitemservice.item.Exception.orderItem.QuantityMissingException;
import com.oms.orderitemservice.item.common.ErrorCodes;
import com.oms.orderitemservice.item.common.ErrorResponse;

import lombok.extern.slf4j.Slf4j;

@RestControllerAdvice
@Slf4j
public class ExceptionAdvice {

	@ExceptionHandler(value = OrderItemNotFoundException.class)
	public ResponseEntity<?> exception(OrderItemNotFoundException e) {

		log.error("Order item note found :", e);
		return ResponseEntity.status(HttpStatus.NOT_FOUND)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.ORDER_ITEM_NOT_FOUND.getCode())
						.errorMessage(ErrorCodes.ORDER_ITEM_NOT_FOUND.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = ProductCodeMissingException.class)
	public ResponseEntity<?> exception(ProductCodeMissingException e) {

		log.error("Product code missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.PRODUCT_CODE_MISSING.getCode())
						.errorMessage(ErrorCodes.PRODUCT_CODE_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = ProductNameMissingException.class)
	public ResponseEntity<?> exception(ProductNameMissingException e) {

		log.error("Product name missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.PRODUCT_NAME_MISSING.getCode())
						.errorMessage(ErrorCodes.PRODUCT_NAME_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = QuantityMissingException.class)
	public ResponseEntity<?> exception(QuantityMissingException e) {

		log.error("Quantity missing :", e);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED)
				.body(ErrorResponse.builder().errorCode(ErrorCodes.QUANTITY_MISSING.getCode())
						.errorMessage(ErrorCodes.QUANTITY_MISSING.getDescription()).timeStamp(LocalDateTime.now())
						.build());
	}

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<?> handleGenericNotFoundException(Exception e) {
		log.error("Error while processing order :", e);
		return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);

	}

}
